![MasterHead](https://github.com/tusharpatil2912/tusharpatil2912/blob/main/banner.gif)
# 💫 About Me: 
<img align="right" src="https://visitor-badge.laobi.icu/badge?page_id=viraj7066.viraj7066" />
<h1 align="center">
    <img src="https://readme-typing-svg.herokuapp.com/?font=Righteous&size=35&center=true&vCenter=true&width=500&height=70&duration=4000&lines=Hi+There!+👋;+I'm+Viraj+Gujar!;" />
</h1>            
                                                   
<!--<h1 align="center">Hi 👋, I'm Viraj Gujar</h1>-->   
<img align="right" alt="coding" width="350" src="https://github.com/tusharpatil2912/tusharpatil2912/blob/main/giphy.gif">

🔭 I’m currently working on: Exciting coding projects and innovations.

👯 I’m looking to collaborate on: Innovative tech ventures and coding challenges.

🤝 I’m looking for help with: Mastering new coding languages and frameworks.

🌱 I’m currently learning: Advanced computer engineering concepts and algorithms.

💬 Ask me about: My latest coding endeavors and tech passions.

📩 How to reach me : gujarviraj0@gmail.com

⚡ Fun fact: I enjoy experimenting with different programming languages


## 🌐 My Socials:
 
<div align="left">
  <a href="instagram.com/viraj7066" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Instagram&logo=instagram&label=&color=E4405F&logoColor=white&labelColor=&style=flat" height="37" alt="instagram logo"  />
  </a>
  <a href="gujarviraj0@gmail.com" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Gmail&logo=gmail&label=&color=D14836&logoColor=white&labelColor=&style=flat" height="37" alt="gmail logo"  />
  </a>
  <img src="https://img.shields.io/static/v1?message=LinkedIn&logo=linkedin&label=&color=0077B5&logoColor=white&labelColor=&style=flat" height="37" alt="linkedin logo"  />
  <a href="codepen.io/viraj7066" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Codepen&logo=codepen&label=&color=000000&logoColor=white&labelColor=&style=flat" height="37" alt="codepen logo"  />
  </a>
  <a href="codesandbox.io/viraj7066" target="_blank">
    <img src="https://img.shields.io/static/v1?message=Codesandbox&logo=codesandbox&label=&color=040404&logoColor=DBDBDB&labelColor=&style=flat" height="37" alt="codesandbox logo"  />
  </a>
</div>
 
# 💻 Tech Stack:

<img align="right" height="150" src="https://media.tenor.com/rePDfDWO3XoAAAAd/hacking.gif"  />

###



<div align="left">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" height="36" alt="javascript logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg" height="36" alt="html5 logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg" height="36" alt="css3 logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" height="36" alt="python logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/aftereffects/aftereffects-original.svg" height="36" alt="aftereffects logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/androidstudio/androidstudio-original.svg" height="36" alt="androidstudio logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/apache/apache-original.svg" height="36" alt="apache logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/bootstrap/bootstrap-original.svg" height="36" alt="bootstrap logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/canva/canva-original.svg" height="36" alt="canva logo"  />
  <img width="13" />
  <img src="https://cdn.simpleicons.org/codepen/000000" height="36" alt="codepen logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=github" height="36" alt="github logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg" height="36" alt="java logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/linkedin/linkedin-original.svg" height="36" alt="linkedin logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=mysql" height="36" alt="mysql logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/pycharm/pycharm-original.svg" height="36" alt="pycharm logo"  />
  <img width="13" />
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/vscode/vscode-original.svg" height="36" alt="vscode logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=au" height="36" alt="adobeaudition logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=ps" height="36" alt="adobephotoshop logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=pr" height="36" alt="adobepremierepro logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=ae" height="36" alt="adobeaftereffects logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=alpinejs" height="36" alt="alpinelinux logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=gradle" height="36" alt="gradle logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=netlify" height="36" alt="netlify logo"  />
  <img width="13" />
  <img src="https://skillicons.dev/icons?i=php" height="36" alt="php logo"  />
</div>

 
# 📊 GitHub Stats:

![](https://github-readme-stats.vercel.app/api/top-langs/?username=viraj7066&theme=radical&hide_border=false&include_all_commits=false&count_private=false&layout=compact)&nbsp;
![](https://github-readme-stats.vercel.app/api?username=viraj7066&theme=radical&hide_border=false&include_all_commits=false&count_private=false)&nbsp;

![](https://github-readme-streak-stats.herokuapp.com/?user=viraj7066&theme=radical&hide_border=false)

<img align="center" src="https://github-readme-activity-graph.vercel.app/graph?username=viraj7066&area=true&hide_border=true&theme=redical" height="203" alt="activity-graph graph"  />

## 🏆 GitHub Trophies
![](https://github-profile-trophy.vercel.app/?username=viraj7066&theme=radical&no-frame=false&no-bg=true&margin-w=4)



[![](https://visitcount.itsvg.in/api?id=viraj7066&icon=5&color=0)](https://visitcount.itsvg.in)


## GSSOC(24) Badges 🪶
<div style='display:flex; align-items:center; gap: 10px;' align='center'><a href="https://gssoc.girlscript.tech/leaderboard">
<img src="https://raw.githubusercontent.com/GSSoC24/Postman-Challenge/main/docs/assets/Postman%20White.png" width="100px" height="100px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Postman-Challenge/main/docs/assets/1.png" width="100px" height="100px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Postman-Challenge/main/docs/assets/2.png" width="100px" height="100px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Postman-Challenge/main/docs/assets/3.png" width="100px" height="100px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Postman-Challenge/main/docs/assets/4.png" width="100px" height="100px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Postman-Challenge/main/docs/assets/5.png" width="100px" height="100px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Postman-Challenge/main/docs/assets/6.png" width="105px" height="105px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Postman-Challenge/main/docs/assets/7.png" width="100px" height="100px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Postman-Challenge/main/docs/assets/8.png" width="100px" height="100px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Contributor/refs/heads/main/assets/Code%20Luminary.png" width="105px" height="105px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Contributor/refs/heads/main/assets/Git%20Explorer.png" width="100px" height="100px" />
  <img src="https://raw.githubusercontent.com/GSSoC24/Contributor/refs/heads/main/assets/Pull%20Expert.png" width="100px" height="100px" /></a>
</div>


###






